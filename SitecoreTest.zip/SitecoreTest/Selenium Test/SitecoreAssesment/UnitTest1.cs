﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;

namespace SitecoreAssesment
{
    
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]

        public void TestMethod1()
        {
         
            //open browser
            IWebDriver driver = GetChromeDriver();     //(@"C:\Drivers\chromedriver_win32");
            //Navigate to site
            driver.Navigate().GoToUrl("http://carlist.my ");
            driver.Manage().Window.Maximize();

            //condition of car
            IWebElement carCondition = driver.FindElement(By.XPath("//body/main[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/div[1]"));
            //operation
            carCondition.Click();

            //select used
            IWebElement usedCondition = driver.FindElement(By.XPath("//div[contains(text(),'Used')]"));
            usedCondition.Click();

            //click search button
            IWebElement searchBox = driver.FindElement(By.XPath("//body/main[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/form[1]/div[7]/button[1]"));
            searchBox.Click();


            Thread.Sleep(3000);

            //First car result
            IWebElement firstCar = driver.FindElement(By.XPath("/html[1]/body[1]/main[1]/div[2]/div[1]/div[1]/div[1]/div[1]/section[1]/article[1]/div[1]/div[1]/h2[1]"));
            firstCar.Click();

            //looks for the car's price
            string carPrice = driver.FindElement(By.XPath("//body/main[1]/article[1]/section[1]/section[1]/section[4]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/h3[1]")).Text;

            carPrice = carPrice.Replace(",", ""); //remove comma 
            string price = carPrice.Remove(0, 2); //remove 3 first letter in car price

            var priceInt = Int32.Parse(price); // convert string to integer
            int basePrice = 1000; //comparison price rm1000

            if (priceInt > basePrice)
           {
                Console.WriteLine("Car Price is greater than RM1000");
                Assert.IsTrue(priceInt > basePrice); 
            }
            else
                Console.WriteLine("Car Price is less than RM1000");

            driver.Quit();
        }

        private IWebDriver GetChromeDriver()
        {
            var OutPutDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location); //dynamic path
            return new ChromeDriver(OutPutDirectory);
        }
    }
}
